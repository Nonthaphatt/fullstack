import { useState, useEffect, useMemo } from 'react';
import axios from 'axios';

function Calculator({ returnResult }) {
  const [a, setA] = useState('');
  const [b, setB] = useState('');
  const [result, setResult] = useState(null);
  const [operator, setOperator] = useState('');

  
 
  useEffect(() => {
    calculate(a, b, operator);
  }, [a, b, operator]);

  const handleChange = (event) => {
    event.preventDefault();
    const { name, value } = event.target;
    if (name === 'a') setA(parseInt(value));
    if (name === 'b') setB(parseInt(value));
  }

  const calculate = (a, b, operator) => {
    if (!isNaN(a) && !isNaN(b)) {
      switch (operator) {
        case '+':
          setResult(a + b);
          break;
        case '-':
          setResult(a - b);
          break;
        case '*':
          setResult(a * b);
          break;
        case '/':
          setResult(a / b);
          break;
        default:
          setResult(null);
      }
    } else {
      setResult(null);
    }
  }

  useMemo(() => {
    returnResult(result)
  }, [result])

  return (
    <div>
      <input type='number' name='a' value={a} onChange={handleChange} />
      <input type='number' name='b' value={b} onChange={handleChange} />
      <div>
        <button onClick={() => setOperator("+")}>+</button>
        <button onClick={() => setOperator("-")}>-</button>
        <button onClick={() => setOperator("*")}>*</button>
        <button onClick={() => setOperator("/")}>/</button>
      </div>
      {/* <p>{result}</p> */}
    </div>
  );
}

export default Calculator;
