import { useState, useEffect } from "react";

const useCalculation = (a, b) => {
    a = parseInt(a);
    b = parseInt(b);
    const [sum, setSum] = useState(null);

    useEffect(() => {
        setSum(a + b);
    }, [a,b]);

    return [sum];
};

export default useCalculation;