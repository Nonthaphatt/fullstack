import { useEffect, useMemo, useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Calculator from './form'
import Insert from './insert'
import Select from './select'

function App() {
  // const [count, setCount] = useState(0);
  // const [i, setI] = useState(0);
  // const [a, setA] = useState('');
  // const [b, setB] = useState('');
  const [result, setResult] = useState('');
  // const [operator, setOperator] = useState('');
  // const [data, setData] = useState({fname: '', lname: '', country: 'Thailand'});

    //for useCalculate.jsx
  // const [a, setA] = useState('');
  // const [b, setB] = useState('');
  // const [sum] = useCalculation(a, b);
  // const handleCalculation = (event) => {
  //   event.preventDefault();
  //   if(event.target.name == 'a') setA(event.target.value);
  //   if(event.target.name == 'b') setB(event.target.value);
  // }

  // const submit = (event) => {
  //   event.preventDefault();
  //   const formData = new FormData(event.target);
  //   const formDataObject = Object.fromEntries(formData.entries());

  //   setData(formDataObject);
    
  //   console.log('Data:', data);
  // };
  
  // const calculate = (a, b, operator) =>{
  //   if (operator === '+')    setResult((prev) => [...prev, {result:a + b, oper:'+'}]);
  //   if (operator === '-')    setResult((prev) => [...prev, {result:a - b, oper:'-'}]);
  //   if (operator === '*')    setResult((prev) => [...prev, {result:a * b, oper:'*'}]);
  //   if (operator === '/')    setResult((prev) => [...prev, {result:a / b, oper:'/'}]);
  // }
  // const calculate = (a, b, operator) => {
  //   if (!isNaN(a) && !isNaN(b)) {
  //     switch (operator) {
  //       case '+':
  //         setResult(a + b);
  //         break;
  //       case '-':
  //         setResult(a - b);
  //         break;
  //       case '*':
  //         setResult(a * b);
  //         break;
  //       case '/':
  //         setResult(a / b);
  //         break;
  //       default:
  //         setResult(null);
  //     }
  //   } else {
  //     setResult(null);
  //   }
  // }

  // useMemo(() => {
  //   calculate(a, b, operator);
  // }, [a, b, operator]);
  
  // const handleCountryChange = (event) => {
  //   setData({...data, country: event.target.value});
  // }
  // useEffect(()=>{
  //   console.log('Data:', data)
  // }, [data.country])

  // const handleChange = (event) => {

  //   event.preventDefault();

  //   const {name , value } = event.target;
  //   if( name === 'a') setA(parseInt(value));
  //   if( name === 'b') setB(parseInt(value));
  // }

  // const clickHandle = () =>{
  //   setI(i+1)
  // }

  const handleLog = (index) =>{
    const selectedResult = result[index];
    console.log(`operator index${index}: ${selectedResult.oper}`)
  }

  const handleResult = (result) => {
    setResult(result);
  }
  return (
    <>
      {/* <div>
        <a href="https://vitejs.dev" target="_blank">
          <img src={viteLogo} className="logo" alt="Vite logo" />
        </a>
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
      </div> */}
      {/* <h1>PUDO = PEMA</h1>
      <Calculator returnResult={handleResult}/>
      <p>{result}</p> */}
      <Insert />
      {/* <Select /> */}
      {/* <div className="card"> */}
        {/* <button onClick={() => setCount((count) => count + 1)}>
          count is {count}
        </button>
        <p>
          Edit <code>src/App.jsx</code> and save to test HMR
        </p>
        <button onClick={clickHandle}>
          counter is {i}
        </button> */}

        {/* <label htmlFor='a' >a</label>
        <input type='text' name='a' onChange={handleCalculation}></input><br></br>
        <label htmlFor='b' >b</label>
        <input type='text' name='b' onChange={handleCalculation}></input><br></br>
        <p>{sum}</p> */}

        {/* lasted */}
        {/* <div>
          <input type='number' name='a' value={a} onChange={handleChange} />
          <input type='number' name='b' value={b} onChange={handleChange} />
          <div>
            <button onClick={() => setOperator("+")}>
              +
            </button>
            <button onClick={() => setOperator("-")}>
              -
            </button>
            <button onClick={() => setOperator("*")}>
              *
            </button>
            <button onClick={() => setOperator("/")}>
              /
            </button>
          </div>
        </div>
        <p>{result}</p> */}

        {/* <form onSubmit={submit}>
          <label htmlFor='fname' >First name</label>
          <input type='text' name='fname'></input><br></br>
          <label htmlFor='fname' >Last name</label>
          <input type='text' name='lname'></input><br></br>
          
          {data.country !== 'Singapore' && (
            <>
            <label htmlFor='id'>ID</label>
            <input type='text' name='id' />
            <br></br>
            </>
          )}

          {data.country !== 'Thailand' && (
            <>
            <select name="job">
              <option value="Doctor">Doctor</option>
              <option value="NEET">NEET</option>
              <option value="Puma">Pedo</option>
            </select>
            <br></br>
            </>
          )}

          <select name="country" onChange={handleCountryChange}>
            <option value="Thailand">Thailand</option>
            <option value="Singapore">Singapore</option>
            <option value="USA">USA</option>
          </select><br></br>
          <button type='submit'>
              Submit
            </button>
        </form> */}
        {/* <form onSubmit={submit}>
          <div>
            <input type='number' name='a' value={a} onChange={handleChange}/>
            <input type='number' name='b' value={b} onChange={handleChange}/>
            <div>
            <button onClick={() => setOperator("+")}>
              +
            </button>
            <button onClick={() => setOperator("-")}>
              -
            </button>
            <button onClick={() => setOperator("*")}>
              *
            </button>
            <button onClick={() => setOperator("/")}>
              /
            </button>
            </div>
          </div>
        </form>
         */}
        {/* <div>
          {result && result.map((result, index) => (
            <div key={index}>value : {result.result}
              <button onClick={() => handleLog(index)}>
                log
              </button>
            </div>
            
          ))}
        </div> */}

      {/* </div> */}
      {/* <p className="read-the-docs">
        Click on the Vite and React logos to learn more
      </p> */}
    </>
  )
}

export default App
