import { useState, useEffect } from 'react';
import axios from 'axios';
// const [jsonData, setJsonData] = useState({});

function select() {
  const [hasFetched, setHasFetched] = useState(false);

  useEffect(() => {
    if (!hasFetched) {
      selectfunc()
      setHasFetched(true);
    }
  }, [hasFetched]);

  const [persons, setPersons] = useState([]);
  const selectfunc = async () => {
    try {
      axios.get('http://localhost:3000/test').then(res => {
        setPersons(res.data)
        console.log(res.data)
        return
      })

    } catch {
      console.log('error')
    }
  }

  return (
    <>
      <div>
        <input type='submit' name='a' value='select' onClick={() => selectfunc()} />
      </div>
      <ul>
        {persons.map(person => (
          <li key={person.CusID}>{person.Username}</li>
        ))}
      </ul>
    </>
  );
}

export default select;
