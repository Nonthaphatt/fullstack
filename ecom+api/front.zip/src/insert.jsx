import { useState, useEffect} from 'react';
import axios from 'axios';

function insert() {
  // useEffect(() => {
  //   insertfunc()
  // });
  
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [text, setText] = useState('');
  const handleChange = (event) => {
    event.preventDefault();
    const { name, value } = event.target;
    if (name === 'username') setUsername(value);
    if (name === 'password') setPassword(value);
  }
  const insertfunc = async ()=>{
    try {
          axios.post('http://localhost:3000/_login', {
            "username": username,
            "password": password
          }).then(res => {
            if(res.data.message=='login success')setText('Login success !!!')
            console.log(res.data.message)
            return
          })
    }catch(e){
      console.log(e)
    }
  }

  

  return (
    <div>
      <h2>Login</h2>
      <input type='text' name='username' onChange={handleChange}/>
      <input type='text' name='password' onChange={handleChange}/>
      <input type='submit' name='a' value='submit' onClick={insertfunc} />
      <h4>{text}</h4>
    </div>
  );
}

export default insert;
